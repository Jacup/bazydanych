DROP TABLE pracownik;
DROP TABLE oddzial;
DROP TABLE stanowisko;
DROP TABLE umowa;
DROP TABLE oferta;
DROP TABLE klient;
